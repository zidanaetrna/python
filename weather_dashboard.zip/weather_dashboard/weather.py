import requests

API_KEY = '3dae0ef75994f4111e6b1b538c30ed68'  # Your actual API key
BASE_URL = 'http://api.openweathermap.org/data/2.5/weather'

def get_weather(city):
    params = {
        'q': city,
        'appid': API_KEY,
        'units': 'metric'
    }
    response = requests.get(BASE_URL, params=params)
    data = response.json()
    
    # Print the data to see its structure
    print(data)
    
    return data
