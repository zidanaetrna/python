from flask import Flask, render_template, request
from weather import get_weather # mengimport funcxtion dari weather.py

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    weather_data = None
    error_message = None

    if request.method == 'POST':
        city = request.form['city']
        weather_data = get_weather(city)

        if weather_data and weather_data.get('cod') == 200:
            return render_template('index.html', weather=weather_data)
        else:
            error_message = weather_data.get('message', 'city not found or error occured.')

    return render_template('index.html', error=error_message)

if __name__ == '__main__':
    app.run(debug=True)